﻿using System.Collections.Generic;

namespace PandaWebApp.ViewModels.Packages
{
    public class CreatePackageViewModel
    {
        public string Description { get; set; }

        public decimal Weight { get; set; }

        public string ShippingAddress { get; set; }

        public string Recipient { get; set; }
    }
}
