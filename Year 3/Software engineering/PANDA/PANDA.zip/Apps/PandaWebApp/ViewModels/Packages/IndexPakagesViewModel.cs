﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PandaWebApp.ViewModels.Packages
{
    public class IndexPakagesViewModel
    {
        public ICollection<StatusViewModel> Packages { get; set; }
    }
}
