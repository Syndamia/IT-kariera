﻿using System.Collections.Generic;

namespace PandaWebApp.ViewModels.Packages
{
    public class DropListViewModel
    {
        public ICollection<string> Recipients { get; set; }
    }
}
